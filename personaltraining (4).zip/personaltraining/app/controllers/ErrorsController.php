<?php
class ErrorsController extends ControllerBase
{
    public function show404Action()
    {

    }

    public function show401Action()
    {

    }
}
?>