<?php
 
use Phalcon\Mvc\Model\Criteria;
use Phalcon\Paginator\Adapter\Model as Paginator;


class EventController extends ControllerBase
{
    /**
     * Index action
     */
    public function indexAction()
    {
        $this->persistent->parameters = null;
    }

    /**
     * Searches for event
     */
    public function searchAction()
    {
        $numberPage = 1;
        if ($this->request->isPost()) {
            $query = Criteria::fromInput($this->di, 'Event', $_POST);
            $this->persistent->parameters = $query->getParams();
        } else {
            $numberPage = $this->request->getQuery("page", "int");
        }

        $parameters = $this->persistent->parameters;
        if (!is_array($parameters)) {
            $parameters = [];
        }
        $parameters["order"] = "title";

        $event = Event::find($parameters);
        if (count($event) == 0) {
            $this->flash->notice("The search did not find any event");

            $this->dispatcher->forward([
                "controller" => "event",
                "action" => "index"
            ]);

            return;
        }

        $paginator = new Paginator([
            'data' => $event,
            'limit'=> 10,
            'page' => $numberPage
        ]);

        $this->view->page = $paginator->getPaginate();
    }

    /**
     * Displays the creation form
     */
    public function newAction()
    {

    }

    /**
     * Edits a event
     *
     * @param string $title
     */
    public function editAction($title)
    {
        if (!$this->request->isPost()) {

            $event = Event::findFirstBytitle($title);
            if (!$event) {
                $this->flash->error("event was not found");

                $this->dispatcher->forward([
                    'controller' => "event",
                    'action' => 'index'
                ]);

                return;
            }

            $this->view->title = $event->getTitle();

            $this->tag->setDefault("title", $event->getTitle());
            $this->tag->setDefault("start", $event->getStart());
            $this->tag->setDefault("venue", $event->getVenue());
            $this->tag->setDefault("ID", $event->getId());
            
        }
    }

    /**
     * Creates a new event
     */
    public function createAction()
    {
        if (!$this->request->isPost()) {
            $this->dispatcher->forward([
                'controller' => "event",
                'action' => 'index'
            ]);

            return;
        }

        $event = new Event();
        $event->settitle($this->request->getPost("title"));
        $event->setstart($this->request->getPost("start"));
        $event->setvenue($this->request->getPost("venue"));
        $event->setiD($this->request->getPost("ID"));
        

        if (!$event->save()) {
            foreach ($event->getMessages() as $message) {
                $this->flash->error($message);
            }

            $this->dispatcher->forward([
                'controller' => "event",
                'action' => 'new'
            ]);

            return;
        }

        $this->flash->success("event was created successfully");

        $this->dispatcher->forward([
            'controller' => "event",
            'action' => 'index'
        ]);
    }

    /**
     * Saves a event edited
     *
     */
    public function saveAction()
    {

        if (!$this->request->isPost()) {
            $this->dispatcher->forward([
                'controller' => "event",
                'action' => 'index'
            ]);

            return;
        }

        $title = $this->request->getPost("title");
        $event = Event::findFirstBytitle($title);

        if (!$event) {
            $this->flash->error("event does not exist " . $title);

            $this->dispatcher->forward([
                'controller' => "event",
                'action' => 'index'
            ]);

            return;
        }

        $event->settitle($this->request->getPost("title"));
        $event->setstart($this->request->getPost("start"));
        $event->setvenue($this->request->getPost("venue"));
        $event->setiD($this->request->getPost("ID"));
        

        if (!$event->save()) {

            foreach ($event->getMessages() as $message) {
                $this->flash->error($message);
            }

            $this->dispatcher->forward([
                'controller' => "event",
                'action' => 'edit',
                'params' => [$event->getTitle()]
            ]);

            return;
        }

        $this->flash->success("event was updated successfully");

        $this->dispatcher->forward([
            'controller' => "event",
            'action' => 'index'
        ]);
    }

    /**
     * Deletes a event
     *
     * @param string $title
     */
    public function deleteAction($title)
    {
        $event = Event::findFirstBytitle($title);
        if (!$event) {
            $this->flash->error("event was not found");

            $this->dispatcher->forward([
                'controller' => "event",
                'action' => 'index'
            ]);

            return;
        }

        if (!$event->delete()) {

            foreach ($event->getMessages() as $message) {
                $this->flash->error($message);
            }

            $this->dispatcher->forward([
                'controller' => "event",
                'action' => 'search'
            ]);

            return;
        }

        $this->flash->success("event was deleted successfully");

        $this->dispatcher->forward([
            'controller' => "event",
            'action' => "index"
        ]);
    }
	
	public function jsonAction()
	{
		//$this->view->disable();
		$events = Event::find();
		$this->response->resetHeaders();
		$this->response->setContentType('application/json', 'UTF-8');
		$this->response->setContent(json_encode($events));
		return $this->response->send();
	}

}
